<!-- path: CLAUDE.md -->
# Project Memory (AgileVerifFlowCC)
@docs/backlog.md
@docs/architecture.md

## Coding Standards
- Keep functions small, testable; prefer pure functions.
- Follow project linter/formatter; fix violations before commit.

## Definition of Done (Macro)
- All ACs implemented and passing automated tests
- Linting and static checks clean
- Coverage >= threshold
- Docs updated (backlog & architecture)
