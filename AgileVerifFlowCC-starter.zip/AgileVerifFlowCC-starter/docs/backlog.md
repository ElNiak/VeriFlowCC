<!-- path: docs/backlog.md -->
# Story Map (Sprint 0)
- Epic: <name> — Rationale: <why>
  - Feature: <name>
    - Story: US-<EPIC>-01 – <title>
      - Brief: <one line>
      - Initial Acceptance Themes: <bullets>

---
# Stories
<!-- Each story will be appended below using templates/story_sheet.j2 -->
