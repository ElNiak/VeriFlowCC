<!-- path: docs/architecture.md -->
# Component Landscape (Sprint 0)
- Component: <name>
  - Responsibilities:
  - Public Interfaces:
  - Dependencies:

---
## Deltas (by Sprint)
<!-- Each story delta will be appended using templates/design_delta.j2 -->
