<!-- path: docs/reports/README.md -->
This folder contains per-sprint V&V reports rendered from templates/vv_report.j2.
File name convention: vv-sprint-<N>.md
