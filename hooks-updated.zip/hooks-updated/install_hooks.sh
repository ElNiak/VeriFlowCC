#!/usr/bin/env bash
set -euo pipefail
target="${HOME}/.claude/hooks"
backup="${target}.bak.$(date +%s)"
echo "Installing updated hooks to: ${target}"
if [ -d "${target}" ]; then
  echo "Backing up existing hooks to: ${backup}"
  cp -r "${target}" "${backup}"
fi
mkdir -p "${target}"
cp -r "$(dirname "$0")"/* "${target}/"
echo "✅ Installed. Restart Claude Code if necessary."
