# hooks/PreToolUse/mock_content_guard.py
#!/usr/bin/env python3
from __future__ import annotations
import json, sys, re

DATA_EXTS = (".json",".yaml",".yml",".csv",".ndjson",".tsv",".toml",".xml",".txt")
DENY_DIRS = ("mocks","__mocks__","fixtures","fixture","tmp","out")

def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    ti = json.dumps(payload.get("tool_input",""))
    # quick-and-dirty: block creation of new large data in denied dirs (heuristic)
    if any(d in ti for d in DENY_DIRS) and any(ext in ti for ext in DATA_EXTS):
        print(json.dumps({"error":"mock_content_blocked"}))
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
