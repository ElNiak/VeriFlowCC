# hooks/PreToolUse/mock_code_guard.py
#!/usr/bin/env python3
from __future__ import annotations
import json, sys, re

PATTERNS = [r"\bMagicMock\b", r"\bAsyncMock\b", r"@patch\(", r"\bjest\.mock\("]

def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    ti = json.dumps(payload.get("tool_input", ""))
    for pat in PATTERNS:
        if re.search(pat, ti):
            print(json.dumps({"error":"mock_code_blocked","pattern":pat}))
            return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
