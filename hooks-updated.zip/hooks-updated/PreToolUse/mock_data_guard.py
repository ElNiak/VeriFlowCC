# hooks/PreToolUse/mock_data_guard.py
#!/usr/bin/env python3
from __future__ import annotations
import json, sys, re

DENY_DIRS = ("mocks","__mocks__","fixtures","fixture","tmp","out")

def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    ti = json.dumps(payload.get("tool_input",""))
    if any(d in ti for d in DENY_DIRS) and re.search(r"(mock|sample|fixture)", ti, re.I):
        print(json.dumps({"error":"mock_data_blocked"}))
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
