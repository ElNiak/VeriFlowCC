# hooks/PreToolUse/pre_git.py
#!/usr/bin/env python3
from __future__ import annotations
import fnmatch, json, os, re, shlex, sys
from typing import Any, Dict, List, Optional, Tuple

DEFAULT_POLICY = {
    "protectedBranches": ["main", "master", "release/*"],
    "allowForceOn": [],
    "allowForceWithLeaseOn": [],
    "blockNoVerify": True,
}

def env_list(name: str) -> Optional[List[str]]:
    v = os.getenv(name)
    return [s.strip() for s in v.split(",")] if v else None

def load_policy() -> Dict[str, Any]:
    p = dict(DEFAULT_POLICY)
    if (v := env_list("CLAUDE_PROTECTED_BRANCHES")): p["protectedBranches"] = v
    if (v := env_list("CLAUDE_ALLOW_FORCE_ON")): p["allowForceOn"] = v
    if (v := env_list("CLAUDE_ALLOW_FORCE_WITH_LEASE_ON")): p["allowForceWithLeaseOn"] = v
    if (v := os.getenv("CLAUDE_BLOCK_NO_VERIFY")) is not None: p["blockNoVerify"] = v not in {"0","false","False"}
    return p

SEP = {"&&","||",";","|"}

def sh_split(cmd: str) -> List[str]:
    parts, buf, qt = [], "", None
    for ch in cmd:
        if qt:
            buf += ch
            if ch == qt: qt = None
            continue
        if ch in {'"', "'"}:
            buf += ch; qt = ch; continue
        if ch.isspace():
            if buf: parts.append(buf); buf = ""
            continue
        buf += ch
    if buf: parts.append(buf)
    return parts

def current_branch() -> Optional[str]:
    try:
        import subprocess
        out = subprocess.check_output(["git","rev-parse","--abbrev-ref","HEAD"], text=True)
        br = out.strip()
        return br if br and br != "HEAD" else None
    except Exception:
        return None

def parse_push_args(args: List[str]) -> Dict[str, Any]:
    d = {"force": False, "force_with_lease": False, "no_verify": False}
    for a in args:
        if a in {"--force","-f"} or a.startswith("+"):
            d["force"] = True
        if a.startswith("--force-with-lease"):
            d["force_with_lease"] = True
        if a in {"--no-verify","-n"}:
            d["no_verify"] = True
    return d

def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    if payload.get("tool_name") != "Bash":
        return 0
    cmd = payload.get("tool_input","")
    if not isinstance(cmd, str) or "git" not in cmd:
        return 0
    policy = load_policy()
    tokens = sh_split(cmd)
    blocks: List[Dict[str,Any]] = []
    i = 0
    while i < len(tokens):
        if tokens[i] == "git" and i+1 < len(tokens):
            sub = tokens[i+1]
            if sub == "commit":
                args = tokens[i+2:]
                if policy["blockNoVerify"] and any(a in {"--no-verify","-n"} for a in args):
                    blocks.append({"cmd":"git commit","reason":"--no-verify not allowed"})
            if sub == "push":
                args = tokens[i+2:]
                flags = parse_push_args(args)
                br = current_branch() or ""
                is_protected = any(fnmatch.fnmatch(br, pat) for pat in policy["protectedBranches"])
                if flags["force"] and not any(fnmatch.fnmatch(br, pat) for pat in policy["allowForceOn"]):
                    blocks.append({"cmd":"git push","reason":f"force push blocked on {br or 'unknown'}"})
                if flags["force_with_lease"] and (is_protected and not any(fnmatch.fnmatch(br, pat) for pat in policy["allowForceWithLeaseOn"])):
                    blocks.append({"cmd":"git push","reason":f"force-with-lease blocked on {br or 'unknown'}"})
        i += 1

    if blocks:
        print(json.dumps({"error":"git_policy_violation","blocks":blocks}))
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
