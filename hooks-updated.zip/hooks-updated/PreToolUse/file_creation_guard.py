# hooks/PreToolUse/file_creation_guard.py
#!/usr/bin/env python3
from __future__ import annotations
import json, os, re, sys, fnmatch
from pathlib import Path
from typing import Any, List, Dict, Optional

POLICY = {
    "denyNameGlobs": ["*enhanced*","*unified*","*final*","*copy*","*draft*"],
    "denyDirGlobs": ["**/mocks/**","**/__mocks__/**","**/fixtures/**","**/tmp/**","**/out/**"],
    "allowWriteRoots": [".agilevv/**","docs/**","README.md"],
    "maxBytes": 300_000,
    "denyBinary": True,
}

def env_list(name: str) -> Optional[List[str]]:
    v = os.getenv(name)
    return [s.strip() for s in v.split(",")] if v else None

def in_globs(path: str, globs: List[str]) -> bool:
    p = path.replace("\\","/")
    return any(fnmatch.fnmatch(p, g) for g in globs)

def extract_paths(tool_input: Any) -> List[str]:
    paths: List[str] = []
    def walk(x: Any):
        if isinstance(x, dict):
            if "path" in x and isinstance(x["path"], str):
                paths.append(x["path"])
            for v in x.values(): walk(v)
        elif isinstance(x, list):
            for it in x: walk(it)
        elif isinstance(x, str) and x.startswith("cat >"):
            parts = x.split(">")
            if len(parts) > 1:
                target = parts[1].strip().split(" ")[0]
                paths.append(target)
    walk(tool_input)
    # dedupe
    seen, out = set(), []
    for p in paths:
        if p not in seen:
            out.append(p); seen.add(p)
    return out

def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    tool = payload.get("tool_name","")
    if tool not in {"Write","Edit","MultiEdit","Bash"}:
        return 0
    ps = extract_paths(payload.get("tool_input"))
    violations: List[Dict[str,str]] = []
    for p in ps:
        np = p.replace("\\","/")
        if in_globs(np, POLICY["denyNameGlobs"]) or in_globs(np, POLICY["denyDirGlobs"]):
            violations.append({"path": np, "reason":"denied by name/dir policy"})
        if not in_globs(np, POLICY["allowWriteRoots"]) and not np.startswith(".agilevv/"):
            # keep source code writes for implementer only (enforced upstream)
            pass
    if violations:
        print(json.dumps({"error":"file_guard_violation","violations":violations}))
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
