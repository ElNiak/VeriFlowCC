# hooks/PreToolUse/log_pre_tool_use.py
#!/usr/bin/env python3
from __future__ import annotations
import json, sys, traceback
from datetime import datetime
from pathlib import Path
from hooks.utils.constants import get_session_log_dir, timestamp

def main() -> int:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
        sid = payload.get("session_id") or payload.get("conversation_id") or "unknown-session"
        d = get_session_log_dir(sid)
        ts = timestamp()
        fname = f"{ts}_{payload.get('hook_event_name','PreToolUse')}_{payload.get('tool_name','Unknown')}.json"
        out = d / "tool_logs" / fname
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp.replace(out)
        print(f"logged: {out}")
        return 0
    except Exception as e:
        print(f"logging_error: {e}", file=sys.stderr)
        traceback.print_exc()
        return 0

if __name__ == "__main__":
    raise SystemExit(main())
