# hooks/SubagentStop/after_edit.py
#!/usr/bin/env python3
"""On SubagentStop, summarize what changed and suggest the next agent.
- Read-only: prints a checklist; does not modify files.
- Non-blocking unless failures from previous hook are present in payload.
"""
from __future__ import annotations
import json, sys, subprocess

def git_summary() -> str:
    try:
        out = subprocess.check_output(["git","status","--porcelain"], text=True)
        lines = [l for l in out.splitlines() if l.strip()]
        return f"{len(lines)} file(s) changed: " + ", ".join(l.split()[-1] for l in lines[:10])
    except Exception:
        return "git unavailable"

def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    prev = payload.get("previous_hook_issues", {})
    print("— Subagent finished. Quick summary:")
    print("   *", git_summary())
    if prev:
        print("   * Pending issues detected by earlier hooks:", ", ".join(prev.keys()))
        print("   * Suggested next: run test-runner (focused) → implementer → code-reviewer.")
    else:
        print("   * Suggested next: code-reviewer (approve/block), then git-workflow to create PR.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
