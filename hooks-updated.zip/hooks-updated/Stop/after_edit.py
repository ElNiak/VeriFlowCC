# hooks/Stop/after_edit.py
#!/usr/bin/env python3
"""On Stop, ensure that formatting/linting has been applied recently and suggest completion steps.
This hook is informational (non-blocking).
"""
from __future__ import annotations
import subprocess, sys

def main() -> int:
    try:
        # Soft check: show diff summary; rely on PostToolUse to block earlier when needed.
        out = subprocess.check_output(["git","diff","--stat"], text=True)
        print("Session ending. Uncommitted changes summary:")
        print(out.strip())
        print("Next steps: run full test suite (test-runner) → complete-task(s) → git-workflow (PR).")
    except Exception:
        pass
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
