# hooks/utils/constants.py
#!/usr/bin/env python3
"""Shared constants and helpers for Claude Code hooks."""
from __future__ import annotations
import os
from pathlib import Path
from datetime import datetime

# Markers used to detect injected instruction files
PRE_FLIGHT_MARKER = "PRE_FLIGHT_MARKER: AgileVerifFlowCC v1.0"
POST_FLIGHT_MARKER = "POST_FLIGHT_MARKER: AgileVerifFlowCC v1.0"

# Log base directory (override with env var)
LOG_BASE_DIR = os.environ.get("CLAUDE_HOOKS_LOG_DIR", ".claude/logs")

def get_session_id() -> str:
    return os.environ.get("CLAUDE_SESSION_ID", "unknown-session")

def get_session_log_dir(session_id: str | None = None) -> Path:
    sid = session_id or get_session_id()
    d = Path(LOG_BASE_DIR) / sid
    d.mkdir(parents=True, exist_ok=True)
    return d

def timestamp() -> str:
    return datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
