# hooks/UserPromptSubmit/append_default.py
#!/usr/bin/env python3
"""Prompt gate: validate/shape the user's prompt and append helpful context (idempotent)."""
from __future__ import annotations
import json, os, re, sys
from typing import Any

BYPASS_ENV = "CLAUDE_PROMPT_GATE_BYPASS"

BANNED_PATTERNS = [
    r"\brm\s+-rf\s+/(?:\s|$)",
    r"(?i)drop\s+database",
    r"(?i)leak\s+(token|secret|key)",
]

APPEND_LINES = [
    "— Keep diffs small and test-first (TDD).",
    "— If you need to write files, prefer file-creator for docs and implementer for code.",
]

def read_json_stdin() -> dict[str, Any]:
    try:
        return json.loads(sys.stdin.read() or "{}")
    except Exception:
        return {}

def main() -> int:
    if os.environ.get(BYPASS_ENV) in {"1","true","TRUE"}:
        return 0
    data = read_json_stdin()
    prompt = (data.get("user_input") or "").strip()
    for pat in BANNED_PATTERNS:
        if re.search(pat, prompt):
            print(json.dumps({"error":"banned_prompt","pattern":pat}), file=sys.stdout)
            return 2
    # Append guidance (stdout is appended to context on UserPromptSubmit)
    if APPEND_LINES:
        print("\n".join(APPEND_LINES))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
