# hooks/UserPromptSubmit/preflight_inject_and_enforce.py
#!/usr/bin/env python3
"""Inject Pre-Flight rules into Claude Code context at UserPromptSubmit.
- On UserPromptSubmit: print the file so Claude adds it to context (idempotent).
- On PreToolUse(TodoWrite): if marker missing in transcript, block with exit code 2.
"""
from __future__ import annotations
import json, os, sys
from pathlib import Path
from typing import Any
from hooks.utils.constants import PRE_FLIGHT_MARKER

def read_json_stdin() -> dict[str, Any]:
    try:
        return json.loads(sys.stdin.read() or "{}")
    except Exception:
        return {}

def read_file(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8")
    except Exception:
        return ""

def transcript_contains_marker(payload: dict[str, Any], marker: str) -> bool:
    tp = payload.get("transcript_path") or payload.get("transcript")
    if not tp or not isinstance(tp, str) or not os.path.exists(tp):
        return False
    try:
        for line in open(tp, "r", encoding="utf-8", errors="ignore"):
            if marker in line:
                return True
    except Exception:
        return False
    return False

def main() -> int:
    data = read_json_stdin()
    event = data.get("hook_event_name", "")
    tool = data.get("tool_name", "")
    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
    preflight_path = os.path.join(project_dir, ".claude", "instructions", "meta", "pre-flight.md")

    if event == "UserPromptSubmit":
        content = read_file(preflight_path).strip()
        if content:
            print(content)  # injected into context
        return 0

    if event == "PreToolUse" and tool in {"TodoWrite", "Write", "MultiEdit"}:
        if not transcript_contains_marker(data, PRE_FLIGHT_MARKER):
            msg = {
                "error": "preflight_missing",
                "reason": "Pre-Flight rules not found in context transcript.",
                "action": "Add .claude/instructions/meta/pre-flight.md to the context, then retry."
            }
            print(json.dumps(msg))
            return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
