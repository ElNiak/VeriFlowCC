# hooks/PostToolUse/after_edit.py
#!/usr/bin/env python3
"""Format & lint only files touched by this tool call; fall back to git changes.
Exit codes:
  0 = OK/auto-fixed; 2 = issues remain and require attention.
"""
from __future__ import annotations
import json, os, subprocess, sys, shlex
from pathlib import Path
from typing import Any, List, Dict, Tuple

PY_FMT = ["black", "--quiet"]
PY_ISORT = ["isort", "--quiet"]
PY_LINT = ["ruff", "check"]
TS_FMT = ["prettier", "--write"]
TS_LINT = ["eslint", "--max-warnings=0"]

CODE_GLOBS = ["**/*.py","**/*.ts","**/*.tsx","**/*.js","**/*.jsx","**/*.md","**/*.json","**/*.yml","**/*.yaml"]

def which(cmd: str) -> bool:
    from shutil import which as w
    return w(cmd) is not None

def from_tool_input(payload: dict[str, Any]) -> List[str]:
    paths: List[str] = []
    ti = payload.get("tool_input")
    def walk(x: Any):
        if isinstance(x, dict):
            if "path" in x and isinstance(x["path"], str):
                paths.append(x["path"])
            for v in x.values(): walk(v)
        elif isinstance(x, list):
            for it in x: walk(it)
        elif isinstance(x, str) and "cat >" in x:
            parts = x.split(">")
            if len(parts)>1:
                target = parts[1].strip().split(" ")[0]; paths.append(target)
    walk(ti)
    # dedupe
    seen,out=set(),[]
    for p in paths:
        p = p.replace("\\","/")
        if p not in seen: seen.add(p); out.append(p)
    return out

def git_changed() -> List[str]:
    try:
        out = subprocess.check_output(["git","diff","--name-only"], text=True)
        return [l.strip() for l in out.splitlines() if l.strip()]
    except Exception:
        return []

def run(cmd: List[str]) -> Tuple[int,str]:
    try:
        out = subprocess.run(cmd, text=True, capture_output=True)
        return out.returncode, (out.stdout + out.stderr).strip()
    except Exception as e:
        return 127, str(e)

def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    tool = payload.get("tool_name","")
    if tool not in {"Write","Edit","MultiEdit"}:
        return 0
    targets = from_tool_input(payload)
    if not targets:
        targets = git_changed()
    # filter to code-y files only
    files = []
    for t in targets:
        p = Path(t)
        if any(p.match(g) for g in CODE_GLOBS) and p.exists():
            files.append(t)
    if not files:
        return 0

    py = [f for f in files if f.endswith(".py")]
    ts = [f for f in files if any(f.endswith(x) for x in [".ts",".tsx",".js",".jsx"])]
    md = [f for f in files if any(f.endswith(x) for x in [".md",".json",".yml",".yaml"])]

    issues: Dict[str,str] = {}

    # Python: format → isort → lint
    if py:
        if which("black"):
            rc, out = run(PY_FMT + py)
        if which("isort"):
            rc, out = run(PY_ISORT + py)
        if which("ruff"):
            rc, out = run(PY_LINT + py)
            if rc != 0:
                issues["ruff"] = out

    # TS/JS
    if ts:
        if which("prettier"):
            rc, out = run(TS_FMT + ts)
        if which("eslint"):
            rc, out = run(TS_LINT + ts)
            if rc != 0:
                issues["eslint"] = out

    # Markdown/JSON/YAML via prettier if available
    if md and which("prettier"):
        rc, out = run(TS_FMT + md)

    if issues:
        print(json.dumps({"hook":"PostToolUse.after_edit","issues":issues,"files":files}, indent=2))
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
