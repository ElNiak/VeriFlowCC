# hooks/PostToolUse/postflight_inject_and_enforce.py
#!/usr/bin/env python3
from __future__ import annotations
import json, os, sys
from typing import Any
from hooks.utils.constants import POST_FLIGHT_MARKER

def read_json() -> dict[str, Any]:
    import sys, json
    try:
        return json.loads(sys.stdin.read() or "{}")
    except Exception:
        return {}

def transcript_contains_marker(payload: dict[str, Any], marker: str) -> bool:
    tp = payload.get("transcript_path") or payload.get("transcript")
    if not tp or not isinstance(tp, str) or not os.path.exists(tp):
        return False
    try:
        for line in open(tp, "r", encoding="utf-8", errors="ignore"):
            if marker in line:
                return True
    except Exception:
        return False
    return False

def main() -> int:
    payload = read_json()
    event = payload.get("hook_event_name","")
    if event != "PostToolUse":
        return 0
    # If the post-flight rules aren't present in context yet, emit a gentle reminder (non-blocking)
    if not transcript_contains_marker(payload, POST_FLIGHT_MARKER):
        note = {
            "note":"postflight_missing",
            "action":"Consider injecting .claude/instructions/meta/post-flight.md into context to verify execution of all steps."
        }
        print(json.dumps(note))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
