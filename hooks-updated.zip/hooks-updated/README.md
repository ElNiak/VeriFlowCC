# Updated Claude Code Hooks for AgileVerifFlowCC

## What’s included
- **UserPromptSubmit**: Injects Pre-Flight rules; gates TodoWrite if missing.
- **PreToolUse**: Git policy guard, file creation guard, logging, mock guards.
- **PostToolUse**: Auto-format + lint on touched files; optional Post-Flight reminder.
- **SubagentStop/Stop**: Summaries and safe next-step hints.

## Exit codes
- `0`: allow
- `2`: block tool call (Claude will surface the JSON and you can retry)

## Install
```bash
bash hooks-updated/install_hooks.sh
```
